package com.six.movie.service;

import com.six.movie.entity.User;
import com.six.movie.query.UserQuery;

import java.util.List;
import java.util.Map;


public interface UserService {


    User selectUserByPassword(String userName, String password);

    Boolean isUserExist(String userName);

    Long addUser(UserQuery query);

    Integer updateUserInfo(UserQuery query);

    Integer modifyUserPwd(String oldPwd, String newPwd, Integer userId);

    List<Map<String, Object>> findAllUser();
}
