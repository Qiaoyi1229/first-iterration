package com.six.movie.utils;

/**
 * 异常信息添加类
 */
public class ExceptionUtil {
    public static String getExceptionMsg(Exception e){
        StringBuffer emsg = new StringBuffer();
        if(e!=null){
            emsg.append(e.getLocalizedMessage() +"\r\n");
            StackTraceElement[] st = e.getStackTrace();
            for (StackTraceElement stackTraceElement : st) {
                emsg.append(stackTraceElement.toString()+"\r\n");
            }
        }
        return emsg.toString();
    }
}
