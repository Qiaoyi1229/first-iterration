package com.six.movie.module;

import lombok.Data;

@Data
public class ResultInfo {

    private Integer code = 200;
    private String msg = "操作成功";

    private Object result;  //返回结果

}
