package com.six.movie.controller;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.six.movie.entity.User;
import com.six.movie.module.BaseResponse;
import com.six.movie.query.UserQuery;
import com.six.movie.service.UserService;
import com.six.movie.utils.ResponseUtil;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 用户管理模块
 */
@RestController
@RequestMapping("/user")
@Slf4j
public class UserController {

    @GetMapping("/index")
    public String index(){
        System.out.println("============");
        return "login";
    }


    @Resource
    private UserService userService;

    @ApiOperation(value = "登录")
    @PostMapping("login")
    @ResponseBody
    public BaseResponse<User> login(@RequestBody UserQuery query, HttpServletRequest request) {
        User user;
        try {
            user = userService.selectUserByPassword(query.getUserName(), query.getPassWord());

            if (user == null || user.getUserId() == null) {
                return ResponseUtil.runfail("用户名或密码错误！");
            }
            HttpSession session = request.getSession();
            session.setAttribute("user", user);
        } catch (Exception e) {
            log.error("用户登录失败", e);
            return ResponseUtil.error("用户登录失败");
        }
        return ResponseUtil.success("用户登录成功", user);
    }

    @ApiOperation(value = "退出")
    @GetMapping("logout")
    @ResponseBody
    public BaseResponse logout(HttpServletRequest request) {
        HttpSession session = request.getSession();
        session.removeAttribute("user");
        return ResponseUtil.success("用户退出成功!");
    }

    @ApiOperation(value = "新建用户")
    @PostMapping(value = "/create")
    @ResponseBody
    public BaseResponse<Map<String, Long>> addUserInfo(@RequestBody UserQuery query) {
        Map<String, Long> userMap = new HashMap<>();
        try {
            Boolean exist = userService.isUserExist(query.getUserName());
            if (exist) {
                return ResponseUtil.runfail("用户已存在");
            }
            Long userId = userService.addUser(query);
            userMap.put("userId", userId);
        } catch (Exception e) {
            log.error("新建用户失败", e);
            return ResponseUtil.error("新建用户失败");
        }
        return ResponseUtil.success("新建用户成功", userMap);
    }

    @ApiOperation(value = "用户信息修改")
    @PostMapping(value = "/updateUser")
    @ResponseBody
    public BaseResponse updateUser(@RequestBody UserQuery query) {
        try {
            Integer rs = userService.updateUserInfo(query);
            if (rs > 0) {
                return ResponseUtil.success("用户信息更新成功!");
            } else {
                return ResponseUtil.error("用户信息更新失败!");
            }
        } catch (Exception e) {
            log.error("用户信息更新失败", e);
            return ResponseUtil.error("用户信息更新失败!");
        }
    }

    @ApiOperation(value = "修改密码")
    @PostMapping(value = "/modifyUserPwd")
    @ResponseBody
    public BaseResponse modifyUserPwd(@RequestBody Map<String, Object> params) {
        String oldPwd = (String) params.get("oldPwd");
        String newPwd = (String) params.get("newPwd");
        Integer userId = (Integer) params.get("userId");
        try {
            Integer rs = userService.modifyUserPwd(oldPwd, newPwd, userId);
            if (null == rs) {
                return ResponseUtil.runfail("密码输入错误,修改失败!");
            } else {
                return ResponseUtil.success("密码成功!");
            }
        } catch (Exception e) {
            log.error("用户信息更新失败", e);
            return ResponseUtil.error("密码修改失败!");
        }
    }

    @ApiOperation(value = "查询所有用户")
    @GetMapping(value = "/findAllUser")
    @ResponseBody
    public BaseResponse<List<Map<String, Object>>> findAllUser() {
        List<Map<String, Object>> rs = null;
        try {
            rs = userService.findAllUser();
        } catch (Exception e) {
            log.error("用户信息查询失败!", e);
            return ResponseUtil.error("用户信息查询失败!");
        }
        return ResponseUtil.success("用户信息查询成功!", rs);
    }

//    @ApiOperation(value = "查询所有用户带分页")
//    @GetMapping(value = "/findAllUserByPage")
//    @ResponseBody
//    public BaseResponse<List<Map<String, Object>>> findAllUserByPage(@RequestParam(value="page",defaultValue="1")Integer page,@RequestParam(value="limit",defaultValue="10")Integer limit,String keyword) {
//        PageInfo<User> info = userService.findAllUserBySplitPage(page, limit, keyword);
//        try {
//            rs = userService.findAllUser();
//        } catch (Exception e) {
//            log.error("用户信息查询失败!", e);
//            return ResponseUtil.error("用户信息查询失败!");
//        }
//        return ResponseUtil.success("用户信息查询成功!", rs);
//    }

}