package com.six.movie.entity;

import lombok.Data;

@Data
public class User {
    private Integer userId;
    private String userName;
    private String passWord;
    private String realName;
    private String phone;
    private String headImage;
    private String email;
}
